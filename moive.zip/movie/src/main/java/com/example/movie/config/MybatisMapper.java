package com.example.movie.config;

public interface MybatisMapper {

}
