package com.example.movie.dto;

import lombok.Data;

@Data
public class BonusDto {

	private String ename;
	private String job;
	private int sal;
	private int comm;

	
}
