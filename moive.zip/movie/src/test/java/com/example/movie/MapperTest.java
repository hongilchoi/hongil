package com.example.movie;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.example.movie.mapper.BonusMapper;

class MapperTest {

	@Autowired
	BonusMapper bonusMapperl;
	
	@Test
	public void insertTest() {
		
	}

}
